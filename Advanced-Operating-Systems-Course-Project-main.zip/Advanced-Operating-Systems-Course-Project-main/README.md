# Advanced-Operating-Systems-Course-Project
Worst Fit Memory Management Algorithm, Optimal Page &amp; Frame Replacement Algorithm, and FCFS Disk Scheduling Algorithm coded in C#

![1](https://user-images.githubusercontent.com/66659379/131348044-3607e64c-3590-4c75-aa74-10aa7e61bdf9.png)
![2](https://user-images.githubusercontent.com/66659379/131348053-9a8b52f5-0a29-41ed-a987-0bc9ed492528.png)
![3](https://user-images.githubusercontent.com/66659379/131348058-b8ca837d-a726-4721-b2ef-4dca05d49a58.png)
![4](https://user-images.githubusercontent.com/66659379/131348062-901598e6-a6ab-4e3d-a5e7-9bf6df70b3bb.png)
